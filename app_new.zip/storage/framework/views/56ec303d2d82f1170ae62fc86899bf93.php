<?php $__env->startSection('content'); ?>
<section class="hero-banner-inner">
  
    <div class="container">
      <div class="row align-items-cneter justify-content-center pt-5">
        <div class="col-md-7">
            <div class="heading-wrapper">
              <div class="text-center text-white">
                <h1 class="fw-semibold px-4 px-lg-0 fs-4 text-uppercase text-white">Best in <?php echo e($category->name); ?> Company</h1>
                <p>Compare the best companies in this category</p>
              </div> 
              
             </div>
             <div class="navbars pt-4">
              <ul>
                <li><a href="/">Home</a></li>
                <?php if($category->parent): ?>
                <li><a href="<?php echo e(url('sub-category',$category->parent->slug)); ?>"><?php echo e($category->parent->name ??''); ?></a></li>
                <?php endif; ?>
                <li><?php echo e($category->name); ?></li>
              </ul>
             </div>
        </div> 
      </div>
    </div>
  </section>
  <section class="py-6 bg-light list-wrapper">
    <div class="container">
      <div class="row">
        <div class="col-md">
         <!--  -->
          <div class="bg-white p-4 rounded-3 mt-4">
            <h5 class="mb-4">Related categories</h5>
             <ul class="categories">
                <?php $__currentLoopData = $relatedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('categories', $category->slug)); ?>"><span><?php echo e($category->name); ?></span> <span><?php echo e($category->company_count); ?></span></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>
          </div>
        </div>
        <div class="col-md-9">
            <div class="d-flex align-items-center justify-content-between pb-4">
                <a class="text-decoration-none text-dark" href="#">1-20 of <?php echo e($companies->total()); ?> results</a>
                <form action="" class="fromsa">
                    <div class="p-1 bg-white rounded rounded-pill shadow-sm">
                        <div class="input-group">
                            <input type="search" placeholder="Searching Company" aria-describedby="button-addon1" class="form-control border-0 bg-white" name="search" value="<?php echo e(request()->query('search')); ?>">
                            <div class="input-group-append">
                                <button id="button-addon1" type="submit" class="btn btn-link text-primary">
                                    <img src="<?php echo e(asset('assets/images/icons/search-interface-symbol.png')); ?>" width="20px" alt="">
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <?php if($companies->isEmpty()): ?>
                <div class="no-companies bg-white p-4 rounded-3 text-center mb-3">
                    <p class="fs-5 text-dark">No companies found.</p>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-wraps bg-white p-4 rounded-3 d-flex mb-3">
                        <div class="list-style1 bg-light p-2 rounded-3 d-flex align-items-center justify-content-center">
                          <?php if($company->logo && file_exists(public_path('logos/' . $company->logo))): ?>
                          <img class="img-fluid rounded-3 bg-light" src="<?php echo e(asset('logos/' . $company->logo)); ?>" alt="<?php echo e($company->website_url); ?>">
                          <?php else: ?>
                          <img class="img-fluid rounded-3 bg-light" src="<?php echo e(asset('assets/images/company/1.png')); ?>" alt="<?php echo e($company->website_url); ?>">
                          <?php endif; ?>
                        </div>
                        <div class="list-style1 ps-5 d-flex align-items-center justify-content-between w-100">
                            <div class="box-styles">
                                <p><a class="text-decoration-none fs-5 text-dark" href="<?php echo e(url('company/'. $company->website_url)); ?>"><?php echo e($company->name); ?></a></p>
                                <div class="d-flex align-items-center mb-2">
                                  <div id="full-stars-example-two">
                                    <div class="rating-group">
                                      <?php for($i = 1; $i <= 5; $i++): ?>
                                          <?php if($i <= $company->averageRating()): ?>
                                              <i class="flaticon-star filled"></i> 
                                          <?php else: ?>
                                              <i class="flaticon-star-empty"></i>
                                          <?php endif; ?>
                                      <?php endfor; ?>
                                  </div>
                                </div>
                                  <ul class="ms-4 mb-0 d-flex">
                                    <li><a href="#"><i class="flaticon-visibility me-1"></i><span class="ps-2"> <?php echo e($company->reviewCount()); ?> reviews</span></a></li>
                                    <li><a href="#"><i class="flaticon-telephone fs-6"></i> <span class="ps-2"><?php echo e($company->phone); ?></span></a></li>
                                  </ul>
                                 </div>
                                 <p><i class="flaticon-pin"></i> <?php echo e($company->city); ?>, <?php echo e($company->country); ?></p>
                                <p><?php echo e($company->location); ?></p>
                                <div class="btn-group">
                                 
                                    <?php $__currentLoopData = $company->category_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="#" class="btn btn-light btn-sm rounded-pill me-2"><?php echo e($category); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <a class="btn btn-light" href="<?php echo e(url('company/'. $company->website_url)); ?>"><span class="btn-title">View Profile</span></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div class="d-flex justify-content-center mt-4">
              <?php echo e($companies->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
        
      </div>
    </div>
  </section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u643724882/domains/reviewbazaar.in/public_html/resources/views/frontend/category/details.blade.php ENDPATH**/ ?>