<?php $__env->startSection('content'); ?>
<section class="hero-banner-inner">
    <!-- <div class="banner-img">
      <img src="assets/images/banner.jpg" alt="Review Bazzar" class="img-fluid">
    </div> -->
    <div class="container">
      <div class="row align-items-cneter justify-content-center pt-5">
        <div class="col-md-7">
            <div class="heading-wrapper">
              <div class="text-center text-white">
                <h1 class="fw-semibold px-4 px-lg-0 fs-4 text-uppercase text-white">Blog - Review Bazzar</h1>
                <p>Check out our trading blog here.</p>
              </div> 
              
             </div>
             <div class="navbars pt-4">
              <ul>
                <li><a href="/">Home</a></li>
                <li><a href="#">Blog</a></li>
              </ul>
             </div>
        </div> 
      </div>
    </div>
  </section>
  <section class="py-6 bg-light list-wrapper blog-wrapper">
    <div class="container">
      <div class="row">
       
        <div class="col-md-8">
        <div class="row g-4">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
          <div class="card h-100">
            <div class="blog-img">
                <?php if($blog->image && file_exists(public_path('images/blog/' . $blog->image))): ?>
                <img class="card-img-top" src="<?php echo e(asset('images/blog/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>" >
                <?php else: ?>
                <img class="card-img-top" src="<?php echo e(asset('assets/images/2.jpg')); ?>" alt="<?php echo e($blog->title); ?>">
                <?php endif; ?>
               <span class="badge"><?php echo e($blog->created_at->format('F j, Y')); ?></span>

            </div>
            <div class="card-body">
                <div class="pb-2"><a class="fs-5 text-decoration-none title" href="<?php echo e(url('blog/' . $blog->slug)); ?>"><?php echo e($blog->title); ?></a></div>
                <p class="card-text">
                    <?php echo \Illuminate\Support\Str::limit(strip_tags($blog->description), 100, '...'); ?>

                </p>
               <div class="pt-3"><a class="btn btn-primary btn-sm" href="<?php echo e(url('blog/' . $blog->slug)); ?>">Read more</a></div> 
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
        </div>
        <div class="col-md">
          <div class="bg-white p-4 rounded-3">
            <h5 class="mb-4">Categories</h5>
             <ul class="categories">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('categories', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>
          </div>
          <div class="recent-post p-4 bg-white rounded-4 mt-4">
             <h5 class="mb-4">Recent Posts</h5>
             <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="d-flex">
                <?php if($blog->image && file_exists(public_path('images/blog/' . $blog->image))): ?>
                <img class="card-img-top rounded-3" width="60px" src="<?php echo e(asset('images/blog/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>" >
                <?php else: ?>
                <img src="assets/images/Listing-image-6.png" class="card-img-top rounded-3" width="60px" alt="<?php echo e($blog->title); ?>" >
                <?php endif; ?>
                <a class="fs-6 text-decoration-none title ps-3 text-dark" href="<?php echo e(url('blog/' . $blog->slug)); ?>"><?php echo e($blog->title); ?></a>
             </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u643724882/domains/reviewbazaar.in/public_html/resources/views/frontend/blog/index.blade.php ENDPATH**/ ?>