<?php $__env->startSection('content'); ?>
<section class="hero-banner position-relative">
  <div class="banner-img">
    <img src="<?php echo e(asset('assets/images/banner.jpg')); ?>" class="img-fluid" alt="">
  </div>
  <div class="container">
    <div class="row align-items-center justify-content-center">
      <div class="col-md-8">
        <div class="heading-wrapper text-center">
          <h1 class="display-3 fw-semibold px-4 px-lg-0 text-white">Welcome To The Biggest<span class="d-md-block"> Business Directory</span></h1>
          <form action="<?php echo e(route('company.review')); ?>" class="fromsa">
            <div class="p-2 p-md-2 bg-white rounded rounded-pill shadow-sm my-4 py-2">
              <div class="d-flex align-items-center justify-content-center px-2">
                <input type="text" placeholder="Location..." `="" class="form-control border-0 bg-white" name="location">
                <input type="text" placeholder="Searching company..." class="form-control border-0 bg-white" name="name">
                <div class="input-group-append btn btn-primary h-100 rounded-pill">
                  <button id="button-addon1" type="submit" class="btn btn-link text-primary"><img src="<?php echo e(asset('assets/images/search.png')); ?>" width="20px" alt=""></button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div> 
    </div>
  </div>
</section>
<section class="py-5 category-wrappers bg-light">
  <div class="container">
    <div class="row pb-5">
      <div class="col-md-12">
          <div class="text-center">
            <h2>The Ultimate Comapny of Category</h2>
            <p class="mb-0">The Definitive Guide to Category Insights and Reviews</p>
          </div>
      </div>
    </div>
    <div class="row row-cols-2 row-cols-sm-4 row-cols-md-4 row-cols-xl-6 g-3">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col">
          <div class="item-list align-items-center bg-white d-flex flex-column justify-content-between">
             <div class="icons-list">
                  <a href="<?php echo e(url('sub-category/'. $category->slug)); ?>">
                    <?php if($category->image && file_exists(public_path('images/category/' . $category->image))): ?>
                    <img src="<?php echo e(asset('images/category/' . $category->image)); ?>" alt="">
              
                    <?php else: ?>
                    <img src="<?php echo e(asset('assets/images/icons/automotive.png')); ?>" alt="">
                    
                <?php endif; ?>
                  </a>
              </div>
             <a class="text-decoration-none text-dark" href="<?php echo e(url('sub-category/'. $category->slug)); ?>"><?php echo e($category->name??''); ?></a>
          </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<section class="copmany-wrapper py-6 bg-white">
  <div class="container">
      <div class="d-flex align-items-center justify-content-between pb-5">
          <div class="title-wrap">
            <h2>Latest Business Reviews</h2>
            <p class="mb-0">Explore our Job Portal's to streamline your job search.</p>
          </div>
          <div class="d-none d-md-block">
            <a class="btn btn-primary rounded-pill btn-lg" href="<?php echo e(route('review-list')); ?>">See more</a>
          </div>
      </div>
    <div class="row reviews-warp g-3">
     <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-4 col-md-6">
        <div class="p-3 rounded-3 bg-white border h-100">
            <div class="d-flex align-items-start">
                <div class="user-iconss bg-primary p-2 rounded-circle text-white" style="width:40px; height:40px">
                  <?php echo e($review->user->getInitials()); ?>

                </div>
                <div class="ps-3">
                    <h6 class="mb-1"><?php echo e($review->user->name); ?></h6>
                    <div id="full-stars-example-two">
                      <div class="rating-group pb-2">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <?php if($i <= $review->review): ?>
                                <i class="fas fa-star" style="color: orange;"></i> <!-- Filled star -->
                            <?php else: ?>
                                <i class="far fa-star" style="color: lightgray;"></i> <!-- Empty star -->
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    </div>
                    <a class="small" href="<?php echo e(url('company', $review->company->website_url)); ?>"><?php echo e($review->company->website_url); ?></a>
                </div>
            </div>
            <div class="pt-2">
                <p class="mb-0"><?php echo \Illuminate\Support\Str::limit(strip_tags($review->comment), 75, '...'); ?></p>
            </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>

<section class="list-wrapper py-5 bg-light home-list">
  <div class="container">
         <div class="text-center mb-5">
            <div class="title-wrap m-auto">
              <h2>Feature Business</h2>
              <p class="mb-0">Discover the voices of success! Our candidates speak for themselves about their<span class="d-md-block"> transformative experiences</span></p>
           </div>
        </div>
    <div class="row align-items-center">
    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xl-6">
              <div class="list-wraps bg-white p-3 rounded-3 d-md-flex mb-3 border">
                  <div class="list-style1s bg-light p-3 p-md-2 rounded-3 d-flex align-items-center justify-content-center">
                 <?php if($company->logo && file_exists(public_path('logos/' . $company->logo))): ?>
                    <img class="img-fluid rounded-3" src="<?php echo e(asset('logos/' . $company->logo)); ?>" width="70px" alt="">
                    <?php else: ?>
                        <img class="img-fluid rounded-3" src="<?php echo e(asset('assets/images/company/1.png')); ?>" width="70px" alt="">
                    <?php endif; ?>
                    </div>
                  <div class="list-style1 ps-4 d-flex align-items-center">
                      <div class="box-styles pt-3 mt-md-0">
                          <p class="mb-1"><a class="text-decoration-none fs-5 text-dark" href="<?php echo e(url('company', $company->website_url)); ?>"><?php echo e($company->name); ?></a></p>
                          <div id="full-stars-example-two">
                            <div class="rating-group pb-2">
                              <?php for($i = 1; $i <= 5; $i++): ?>
                                  <?php if($i <= $company->averageRating()): ?>
                                      <i class="fas fa-star" style="color: orange;"></i> <!-- Filled star -->
                                  <?php else: ?>
                                      <i class="far fa-star" style="color: lightgray;"></i> <!-- Empty star -->
                                  <?php endif; ?>
                              <?php endfor; ?>
                          </div>
                          <div class="d-flex align-items-center mb-2">
                              <ul class="mb-0 d-flex">
                                  <li><a href="#"><i class="flaticon-visibility me-1"></i><span class="ps-2"><?php echo e($company->reviewCount()); ?>   reviews</span></a></li>
                                  <li><a href="#"><i class="flaticon-telephone fs-6"></i> <span class="ps-2"><?php echo e($company->phone); ?></span></a></li>
                              </ul>
                          </div>
                          <p><i class="flaticon-pin"></i> <?php echo e($company->city ?? ''); ?>, <?php echo e($company->country ?? ''); ?></p>
                      </div>

                  </div>
              </div>
          </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>
<section class="py-5">
  <div class="container">
    <div class="text-center mb-5">
        <div class="title-wrap m-auto">
          <h2>Looking for a local business?</h2>
          <p class="mb-0">Discover the voices of success! Our candidates speak for themselves about their<span class="d-md-block"> transformative experiences</span></p>
        </div>
    </div>
    <div class="row g-3">
      <div class="col-xl-3 col-md-6">
        <div class="p-4 bg-light rounded-3 shadow-sm text-center h-100">
          <div class="bg-primary rounded-3 d-flex align-items-center justify-content-center" style="width:60px; height:60px; margin: auto;"><img src="assets/images/options.png" width="35px" alt=""></div>
          <h4 class="pt-3">Multiple options</h4>
          <p class="mb-0">You will get multiple options to choose from for your classified searches. Also, you can see reviews and ratings by the people.</p>
        </div>
      </div>
      <div class="col-xl-3 col-md-6">
        <div class="p-4 bg-light rounded-3 shadow-sm text-center h-100">
          <div class="bg-primary rounded-3 d-flex align-items-center justify-content-center" style="width:60px; height:60px; margin: auto;"><img src="assets/images/easy-installation.png" width="35px" alt=""></div>
          <h4 class="pt-3">Easy to find</h4>
          <p class="mb-0">Just fill in your requirements and location and get the list of the best service providers near you suitable to your needs.</p>
        </div>
      </div>
      <div class="col-xl-3 col-md-6">
        <div class="p-4 bg-light rounded-3 shadow-sm text-center h-100">
          <div class="bg-primary rounded-3 d-flex align-items-center justify-content-center" style="width:60px; height:60px; margin: auto;"><img src="assets/images/integration.png" width="35px" alt=""></div>
          <h4 class="pt-3">It's very local</h4>
          <p class="mb-0">We make your search for a particular local service easy and convenient with our easy to find functions.</p>
        </div>
      </div>
      <div class="col-xl-3 col-md-6">
        <div class="p-4 bg-light rounded-3 shadow-sm text-center h-100">
          <div class="bg-primary rounded-3 d-flex align-items-center justify-content-center" style="width:60px; height:60px; margin: auto;"><img src="assets/images/customer-service.png" width="35px" alt=""></div>
          <h4 class="pt-3">24/7 support system</h4>
          <p class="mb-0">When you submit any query to us, we try our best to respond as soon as possible. We are active 24/7.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="py-6 list-wrapper bg-light home-list">
  <div class="container">
      <div class="text-center mb-5">
          <div class="title-wrap m-auto">
              <h2>New Businesses</h2>
              <p class="mb-0">Discover the voices of success! Our candidates speak for themselves about their<span class="d-md-block"> transformative experiences</span></p>
          </div>
      </div>
      <div class="row">
        <?php $__currentLoopData = $newCompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xl-6">
              <div class="list-wraps bg-white p-3 rounded-3 d-md-flex mb-3 border">
                  <div class="list-style1 img-view bg-white p-3 p-md-2 rounded-3 border d-flex align-items-center justify-content-center">
                    <?php if($company->logo && file_exists(public_path('logos/' . $company->logo))): ?>
                    <img class="img-fluid rounded-3" src="<?php echo e(asset('logos/' . $company->logo)); ?>" width="70px" alt="">
                    <?php else: ?>
                        <img class="img-fluid rounded-3" src="<?php echo e(asset('assets/images/company/1.png')); ?>" width="70px" alt="">
                    <?php endif; ?>
                  </div>
                  <div class="list-style1 ps-4 d-flex align-items-center">
                      <div class="box-styles pt-3 pt-md-0">
                          <p class="mb-1"><a class="text-decoration-none fs-5 text-dark" href="<?php echo e(url('company', $company->website_url)); ?>"><?php echo e($company->name); ?></a></p>
                          <div id="full-stars-example-two" class="mb-2">
                            <div class="rating-group">
                              <?php for($i = 1; $i <= 5; $i++): ?>
                                  <?php if($i <= $company->averageRating()): ?>
                                      <i class="fas fa-star" style="color: orange;"></i> <!-- Filled star -->
                                  <?php else: ?>
                                      <i class="far fa-star" style="color: lightgray;"></i> <!-- Empty star -->
                                  <?php endif; ?>
                              <?php endfor; ?>
                          </div>
                          </div>
                          <div class="d-flex align-items-center mb-2">
                              <ul class="mb-0 d-flex">
                                  <li><a href="#"><i class="flaticon-visibility me-1"></i><span class="ps-2"><?php echo e($company->reviewCount()); ?>  reviews</span></a></li>
                                  <li><a href="#"><i class="flaticon-telephone fs-6"></i> <span class="ps-2"><?php echo e($company->phone); ?></span></a></li>
                              </ul>
                          </div>
                          <p><i class="flaticon-pin"></i> <?php echo e($company->city ?? ''); ?>, <?php echo e($company->country ?? ''); ?></p>
                      </div>

                  </div>
              </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
  </div>
</section>
<section class="py-5 py-md-6 blog-wrapper bg-white">
  <div class="container">
        <div class="text-center mb-5">
            <div class="title-wrap m-auto">
              <h2>Upcoming activities close to you</h2>
              <p class="mb-0">Discover the voices of success! Our candidates speak for themselves about their<span class="d-md-block"> transformative experiences</span></p>
           </div>
        </div>
    <div class="row g-3">
      <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <div class="card h-100">
          <div class="blog-img">
          <?php if($blog->image && file_exists(public_path('images/blog/' . $blog->image))): ?>
                <img class="card-img-top" src="<?php echo e(asset('images/blog/' . $blog->image)); ?>" alt="...">
          <?php else: ?>
                <img src="<?php echo e(asset('assets/images/Listing-image-6.png')); ?>" class="card-img-top" alt="...">
          <?php endif; ?>
          <span class="badge"><?php echo e($blog->created_at->format('M d, Y')); ?></span>
          </div>
          <div class="card-body">
            <div class="pb-2"><a class="fs-5 text-decoration-none title lh-1" href="<?php echo e(url('blog/' . $blog->slug)); ?>"><?php echo e($blog->title); ?></a></div>
            <p class="card-text"><?php echo \Illuminate\Support\Str::limit(strip_tags($blog->description), 100, '...'); ?></p>
            <div class="pt-3"><a class="small btn btn-primary btn-sm" href="<?php echo e(url('blog/' . $blog->slug)); ?>">Read more</a></div>
          </div>
        </div>
      </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/frontend/index.blade.php ENDPATH**/ ?>