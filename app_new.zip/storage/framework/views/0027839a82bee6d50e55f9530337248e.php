<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">User</h4>
            
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th> Name </th>
                    <th> Email </th>
                    <th> Phone </th>
                    <th> Profile </th>
                    <th> Business </th>
                    <th> Address </th>
                    <th> Action </th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td> <?php echo e($user->name); ?> </td>
                    <td> <?php echo e($user->email); ?> </td>
                    <td>
                      <?php echo e($user->phone); ?>

                    </td>
                    <td class="py-1">
                      <?php if($user->profile && file_exists(public_path('images/profile/' . $user->profile))): ?>
                      <img src="<?php echo e(asset('images/profile/' . $user->profile)); ?>"  alt="">
                      <?php else: ?>
                          <img src="<?php echo e(asset('assets/images/user.jpg')); ?>"  alt="">
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php echo e($user->business); ?>

                    </td>
                    <td>
                      <?php echo e($user->address); ?>

                    </td>
                    <td>
                    
                    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                    </td>
                  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-center">
        <?php echo e($users->links('pagination::bootstrap-4')); ?>

      </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u643724882/domains/reviewbazaar.in/public_html/resources/views/admin/user/index.blade.php ENDPATH**/ ?>