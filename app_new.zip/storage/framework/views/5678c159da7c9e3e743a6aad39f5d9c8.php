<?php $__env->startSection('content'); ?>
 Welcome to dashboard
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>