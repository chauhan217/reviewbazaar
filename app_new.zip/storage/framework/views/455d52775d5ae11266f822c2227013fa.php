<?php $__env->startSection('title', 'Edit Profile'); ?>
<?php $__env->startSection('content'); ?>
<section class="bg-primary py-5">
    <div class="container">
      <div class="row align-items-cneter justify-content-center">
        <div class="col-md-7">
            <div class="heading-wrapper">
              <div class="text-center text-white">
                <div class="profile position-relative m-auto" style="max-width:20%">
                    <?php if($user->profile && file_exists(public_path('images/profile/' . $user->profile))): ?>
                    <img src="<?php echo e(asset('images/profile/' . $user->profile)); ?>" class="rounded-1 border-2 border-light" width="100%" height="120px" style="object-fit: cover;"  alt="">
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/images/user.jpg')); ?>" class="rounded-1 border-2 border-light" width="100%" height="120px" style="object-fit: cover;"  alt="">
                    <?php endif; ?>
                   <div class="position-absolute top-0 end-0">
                        <a href="#" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="assets/images/settings.png" class="bg-primary p-1 rounded-2" width="25px" alt="">
                        </a>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="<?php echo e(url('profile')); ?>">Edit</a></li>
                        </ul>
                    </div>
                </div>
               
                <div class="pt-4">
                  <h1 class="fw-semibold px-4 px-lg-0 fs-4 text-uppercase text-white"><?php echo e($user->name); ?></h1>
                  <ul class="list-unstyled">
                    <li><a class="text-white text-decoration-none" href="#"><?php echo e($user->email); ?></a></li>
                  </ul>
                </div>
              </div> 
            </div>
        </div> 
      </div>
    </div>
  </section>
<section class="py-5">
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <span class="text-success">  <?php echo e(session('success')); ?> </span>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="profile bg-light p-4 rounded-3 text-center">
                        <?php if($user->profile && file_exists(public_path('images/profile/' . $user->profile))): ?>
                        <img src="<?php echo e(asset('images/profile/' . $user->profile)); ?>" class="img-fluid p-1 bg-black rounded-1" width="180px" alt="">
                        <?php else: ?>
                            <img src="<?php echo e(asset('assets/images/user.jpg')); ?>" class="img-fluid p-1 bg-black rounded-1" width="180px" alt="">
                        <?php endif; ?>
                        <div class="pt-4">
                            <h5 class="mb-3 d-flex align-items-center justify-content-center">
                                <span class="ms-2"><?php echo e($user->name); ?></span>
                            </h5>
                            <h6 class="opacity-50 d-flex align-items-center justify-content-center small">
                                <span>Business:</span>
                                <span class="ms-2"><?php echo e($user->business ?? 'N/A'); ?></span>
                            </h6>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="mb-1">
                              Business Category :-
                              <?php $__currentLoopData = $company->category_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($category); ?> <?php if(!$loop->last): ?>, <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </p>
                            <p>(<?php echo e($company->name); ?>)</p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="bg-light p-4">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <th scope="col">Full Name</th>
                                    <td scope="col">
                                        <input class="form-control" type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="col">Phone</th>
                                    <td scope="col">
                                        <input class="form-control" type="text" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>">
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="col">Email</th>
                                    <td scope="col">
                                        <input class="form-control" <?php if(true): echo 'readonly'; endif; ?> type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="col">Business</th>
                                    <td scope="col">
                                        <input class="form-control" type="text" name="business" value="<?php echo e(old('business', $user->business)); ?>">
                                        <?php $__errorArgs = ['business'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="col">Address</th>
                                    <td scope="col">
                                        <input class="form-control" type="text" name="address" value="<?php echo e(old('address', $user->address)); ?>">
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="col">About us</th>
                                    <td scope="col">
                                        <textarea class="form-control" name="about">
                                        <?php echo e(old('about', $user->about)); ?>

                                        </textarea>
                                        <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"> 
                                        <div class="input-group">
                                            <input type="file" class="form-control" id="inputGroupFile02" name="profile">
                                            <label class="input-group-text" for="inputGroupFile02">Upload</label>
                                        </div>
                                        <?php $__errorArgs = ['profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"> 
                                        <div class="input-group">
                                            <button type="submit" class="btn btn-primary">Update</button> 
                                        </div>
                                    </td>
                                </tr>
                            </tbody> 
                        </table>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u643724882/domains/reviewbazaar.in/public_html/resources/views/frontend/profile.blade.php ENDPATH**/ ?>