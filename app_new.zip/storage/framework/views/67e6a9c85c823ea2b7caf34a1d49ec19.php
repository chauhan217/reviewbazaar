<?php $__env->startSection('content'); ?>
 Welcome to dashboard
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u643724882/domains/reviewbazaar.in/public_html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>