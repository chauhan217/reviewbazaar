<?php $__env->startSection('content'); ?>
<section class="post-details">
 <?php if($page->image && file_exists(public_path('images/pages/' . $page->image))): ?>
 <img  class="img-fluid" src="<?php echo e(asset('images/pages/' . $page->image)); ?>" alt="image" width="100%">
 <?php endif; ?>
 <div class="container py-5">
   <div class="row align-items-center justify-content-center">
       <div class="col-md-9">
         <?php echo html_entity_decode($page->description); ?>

       </div> 
   </div>
 </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u643724882/domains/reviewbazaar.in/public_html/resources/views/frontend/page.blade.php ENDPATH**/ ?>