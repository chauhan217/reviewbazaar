<?php $__env->startSection('content'); ?>

<section class="hero-banner-inner">
    <div class="container">
        <div class="row align-items-cneter justify-content-center pt-5">
            <div class="col-md-7">
                <div class="heading-wrapper">
                    <div class="text-center text-white">
                        <h1 class="fw-semibold px-4 px-lg-0 fs-4 text-uppercase text-white">Best in Travel Insurance Company</h1>
                        <p>Compare the best companies in this category</p>
                    </div> 
                </div>
                <div class="navbars pt-4">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#"><?php echo e($company->name ?? ''); ?></a></li>
                        <li>Review</li>
                    </ul>
                </div>
            </div> 
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row aligin-items-center justify-content-center">
            <div class="col-md-5">
                <div class="p-4 bg-light rounded-2">
                    
                    <!-- Display Success Message -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <span class="text-success">  <?php echo e(session('success')); ?> </span>
                        </div>
                    <?php endif; ?>

                    <h4 class="text-uppercase">Customer Review Form</h4>
                    <p>We value your feedback. Please take a moment to review your experience with us.</p>
                    <form class="row" action="<?php echo e(route('review.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="company_id" value="<?php echo e($company->id); ?>">
                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">

                        <!-- Name -->
                        <div class="mb-3 col-md-6">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name', auth()->user()->name)); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Email -->
                        <div class="mb-3 col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email', auth()->user()->email)); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Phone -->
                        <div class="mb-3 col-md-12">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e(old('phone')); ?>">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Rating -->
                        <div class="mb-3 col-md-12">
                            <h5 class="text-uppercase">Quality of Services</h5>
                            <p class="opacity-50 mb-0">Rate your overall experience with us</p>
                            <div id="full-stars-example-two">
                                <div class="rating-group">
                                    <input disabled="" checked="" class="rating__input rating__input--none" name="review" id="rating-none" value="0" type="radio">
                                    <label aria-label="1 star" class="rating__label" for="rating-1"><i class="rating__icon rating__icon--star flaticon-star"></i></label>
                                    <input class="rating__input" name="review" id="rating-1" value="1" type="radio">
                                    <label aria-label="2 stars" class="rating__label" for="rating-2"><i class="rating__icon rating__icon--star flaticon-star"></i></label>
                                    <input class="rating__input" name="review" id="rating-2" value="2" type="radio">
                                    <label aria-label="3 stars" class="rating__label" for="rating-3"><i class="rating__icon rating__icon--star flaticon-star"></i></label>
                                    <input class="rating__input" name="review" id="rating-3" value="3" type="radio">
                                    <label aria-label="4 stars" class="rating__label" for="rating-4"><i class="rating__icon rating__icon--star flaticon-star"></i></label>
                                    <input class="rating__input" name="review" id="rating-4" value="4" type="radio">
                                    <label aria-label="5 stars" class="rating__label" for="rating-5"><i class="rating__icon rating__icon--star flaticon-star"></i></label>
                                    <input class="rating__input <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="review" id="rating-5" value="5" type="radio">
                                </div>
                            </div>
                            <?php $__errorArgs = ['review'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Comments -->
                        <div class="col-md-12">
                            <div class="form-floating">
                                <textarea class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="comment" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"><?php echo e(old('comment')); ?></textarea>
                                <label for="floatingTextarea2">Comments</label>
                            </div>
                            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Terms & Conditions -->
                        <div class="col-md-12">
                            <div class="mb-3 form-check mt-4">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['agreement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleCheck1" name="agreement">
                                <label class="form-check-label" for="exampleCheck1">I agree that my review can be published on the website.</label>
                            </div>
                            <?php $__errorArgs = ['agreement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button type="submit" class="btn btn-primary">Submit Review</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/frontend/review.blade.php ENDPATH**/ ?>