<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Blog</h4>
            <p class="card-description"> 
                <a href="<?php echo e(route('blog.create')); ?>" class="btn btn-primary">Add Blog</a>
            </p>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th> Title </th>
                    <th> Slug </th>
                    <th> Image </th>
                    <th> Status </th>
                    <th> Action </th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td> <?php echo e($blog->title); ?> </td>
                    <td> <?php echo e($blog->slug); ?> </td>

                    <td class="py-1">
                      <?php if($blog->image && file_exists(public_path('images/blog/' . $blog->image))): ?>
                      <img src="<?php echo e(asset('images/blog/' . $blog->image)); ?>" alt="image">
                      <?php endif; ?>
                    </td>
                    <td>
                        <?php if($blog->status === 'active'): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Inactive</span>
                    <?php endif; ?>
                    </td>
                    <td>
                      <a href="<?php echo e(url('blog/'.$blog->slug)); ?>" target="_blank" class="btn btn-primary btn-sm">View</a>
                    <a href="<?php echo e(route('blog.edit', $blog->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('blog.destroy', $blog->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                    </td>
                  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
               
              </table>
             
            </div>
           
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-center">
        <?php echo e($blogs->links('pagination::bootstrap-4')); ?>

      </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u643724882/domains/reviewbazaar.in/public_html/resources/views/admin/blog/index.blade.php ENDPATH**/ ?>