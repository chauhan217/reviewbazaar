<section class="hero-banner-inner">

    <div class="container">
        <div class="row align-items-cneter justify-content-center pt-5">
            <div class="col-md-7">
                <div class="heading-wrapper">
                    <div class="text-center text-white">
                        <h1 class="fw-semibold px-4 px-lg-0 fs-4 text-uppercase text-white">Best in Company</h1>
                        <p>Compare the best companies in this category</p>
                    </div>

                </div>
                <div class="navbars pt-4">
                    <ul>
                        <li><a href="/">Home</a></li>
                        
                        <li>User Profile</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <span class="text-success"> <?php echo e(session('success')); ?> </span>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-mb-12">
                <div class="row g-4 align-items-start">
                    <div class="col-md-3">
                        <div class="bg-light p-4 rounded-3">
                            <h3 class="mb-4">My Dashboard</h3>
                            <div class="border p-4 text-center mb-4 bg-white rounded-4">
                                <?php if($user->profile && file_exists(public_path('images/profile/' . $user->profile))): ?>
                                    <img src="<?php echo e(asset('images/profile/' . $user->profile)); ?>"
                                        class="rounded-1 border-2 border-light" width="100%" height="120px"
                                        style="object-fit: cover;" alt="">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/user.jpg')); ?>"
                                        class="rounded-1 border-2 border-light" width="100%" height="120px"
                                        style="object-fit: cover;" alt="">
                                <?php endif; ?>
                                <span class="d-block w-75 m-auto mt-4"><?php echo e($user->name); ?></span>
                            </div>
                            <div class="nav flex-column nav-pills me-3 text-start border-bottom lh-lg" id="v-pills-tab"
                                role="tablist" aria-orientation="vertical">
                                <a href="<?php echo e(route('user.profile')); ?>" class="nav-link text-start active border-bottom lh-lg"
                                     type="button" 
                                     aria-selected="true">My Profile</a>

                                     <a href="<?php echo e(route('user.profile')); ?>" class="nav-link text-start border-bottom lh-lg"
                                     type="button" 
                                     aria-selected="true">Change Password</a>
                                     <a href="<?php echo e(route('user.profile')); ?>" class="nav-link text-start border-bottom lh-lg"
                                     type="button" 
                                     aria-selected="true">My Reviews</a>
                                     <a href="<?php echo e(route('user.profile')); ?>" class="nav-link text-start border-bottom lh-lg"
                                     type="button" 
                                     aria-selected="true">My Business</a>
                                     <a href="<?php echo e(route('user.profile')); ?>" class="nav-link text-start border-bottom lh-lg"
                                     type="button" 
                                     aria-selected="true">My Blogs</a>
                                     <a href="<?php echo e(route('user.profile')); ?>" class="nav-link text-start border-bottom lh-lg"
                                     type="button" 
                                     aria-selected="true">Logout</a>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="tab-content" id="v-pills-tabContent">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/app/resources/views/frontend/inc/profilebanner.blade.php ENDPATH**/ ?>