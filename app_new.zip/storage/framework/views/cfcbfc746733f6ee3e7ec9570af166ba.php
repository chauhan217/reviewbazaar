<div class="tab-pane fade show active" id="v-pills-blogs" role="tabpanel" aria-labelledby="v-pills-blogs-tab" tabindex="0">
    <div class="row">
        <div class="col-md-12">
            <div class="py-4">
                <a class="btn btn-primary" href="<?php echo e(route('user.blogs.add')); ?>">+ Add Blog</a>
            </div>
            <div class="bg-light p-4 rounded-3">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">Blog Title</th>
                            
                            <th scope="col">Date</th>
                            <th scope="col">Active</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($blog->title); ?></td>
                            
                            <td><?php echo e(date('d-m-Y', strtotime($blog->created_at))); ?></td>
                            <td>  <?php if($blog->status === 'active'): ?>
                                Active
                            <?php else: ?>
                               Inactive
                            <?php endif; ?></td>
                            <td><div class="d-flex">
                                <a class="btn btn-light" href="<?php echo e(route('user.blogs.edit',$blog->id)); ?>"><span class="btn-title"><img
                                            src="assets/images/edit.png" width="18px" alt=""></span></a>
                                <a class="btn btn-light ms-3" href="<?php echo e(route('blog-details',$blog->slug)); ?>"><span class="btn-title"><img
                                            src="assets/images/show.png" width="18px" alt=""></span></a>
                            </div></td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/app/resources/views/frontend/inc/myblog.blade.php ENDPATH**/ ?>