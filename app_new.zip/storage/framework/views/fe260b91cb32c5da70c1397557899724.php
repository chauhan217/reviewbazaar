<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Category</h4>
            <p class="card-description"> 
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Add Category</a>
            </p>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th> Name </th>
                    <th> Parent Category</th>
                    <th> Slug </th>
                    <th> Logo </th>
                    <th> Status </th>
                    <th> Action </th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td> <?php echo e($category->name); ?> </td>
                    <td> <?php echo e($category->parent->name ?? ''); ?> </td>

                    <td> <?php echo e($category->slug); ?> </td>

                    <td class="py-1">
                     <?php if($category->image): ?>
                         <img src="<?php echo e(asset('images/category')); ?>/<?php echo e($category->image); ?>" alt="image">
                      <?php endif; ?>
                    </td>
                    <td>
                        <?php if($category->status === 'active'): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Inactive</span>
                    <?php endif; ?>
                    </td>
                    <td>
                    
                    <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                    </td>
                  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
               
              </table>
            </div>
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-center">
        <?php echo e($categories->links('pagination::bootstrap-4')); ?>

      </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>