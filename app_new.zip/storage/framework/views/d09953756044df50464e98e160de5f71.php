<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Company</h4>
            <p class="card-description"> 
                <a href="<?php echo e(route('company.create')); ?>" class="btn btn-primary">Add Company</a>
            </p>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th> Name </th>
                    <th> Website </th>
                    <th> Image </th>
                    <th> Status </th>
                    <th> Action </th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td> <?php echo e($company->name); ?> </td>
                    <td> <?php echo e($company->website_url); ?> </td>

                    <td class="py-1">
                      <?php if($company->logo && file_exists(public_path('logos/' . $company->logo))): ?>
                      <img src="<?php echo e(asset('logos')); ?>/<?php echo e($company->logo); ?>" alt="logo">
                      <?php endif; ?>
                    </td>
                    <td>
                        <?php if($company->status === 'active'): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Inactive</span>
                    <?php endif; ?>
                    </td>
                    <td>
                    <a href="<?php echo e(route('company.edit', $company->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('company.destroy', $company->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                    </td>
                  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
              </table>
            </div>
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-center">
        <?php echo e($companies->links('pagination::bootstrap-4')); ?>

      </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u643724882/domains/reviewbazaar.in/public_html/resources/views/admin/company/index.blade.php ENDPATH**/ ?>