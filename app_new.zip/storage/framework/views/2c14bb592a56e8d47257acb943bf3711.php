<?php $__env->startSection('title'); ?>
<?php echo e($blog->title); ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
    <meta property="og:title" content="<?php echo e($blog->meta_title ?? $blog->title); ?>" />
    <meta property="og:description" content="<?php echo e($blog->meta_description ?? html_entity_decode($blog->description)); ?>" />
    <?php if($blog->image && file_exists(public_path('images/blog/' . $blog->image))): ?>
    <meta property="og:image" content="<?php echo e(asset('images/blog/' . $blog->image)); ?>"  alt="image"/>
    <?php endif; ?>
    <meta property="og:url" content="<?php echo e(url('/blog', $blog->slug)); ?>" />
    <meta property="og:keywords" content="<?php echo e($blog->meta_key); ?>" />
    <meta property="og:type" content="article" />
    <meta property="article:published_time" content="<?php echo e($blog->created_at->toRfc3339String()); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="post-details py-5 bg-primary">
    <div class="container">
      <div class="row align-items-center justify-content-center">
          <div class="col-md-8 text-center">
              <h1 class="text-white"><?php echo e($blog->title); ?></h1>
          </div>
      </div>
    </div>
</section>    
<section class="py-5">
  <div class="container">
    <div class="row">
      <div class="col-xl-8">
          <div class="bg-light p-2 shadow-sm mb-3">
              <nav aria-label="breadcrumb" class="d-flex align-items-center justify-content-start p3-3">
                  <ol class="breadcrumb mb-0">
                      <li class="breadcrumb-item"><a class="text-decoration-none small text-dark" href="#"><?php echo e($blog->created_at->format('F j, Y')); ?></a></li>
                      <li class="breadcrumb-item active"><a class="text-decoration-none small text-dark" href="#"><?php echo e($blog->category->name); ?></a></li>
                  </ol>
              </nav>
          </div>
          <div class="p-3 border bg-light">
            <?php if($blog->image && file_exists(public_path('images/blog/' . $blog->image))): ?>
              <img  class="img-fluid" src="<?php echo e(asset('images/blog/' . $blog->image)); ?>" alt="image" width="100%">
              <?php else: ?>
              <img class="img-fluid" src="<?php echo e(asset('assets/images/2.jpg')); ?>" alt="">
              <?php endif; ?>
          </div>
          <div class="border p-3 rounded-3 mt-4">
            <?php echo html_entity_decode($blog->description); ?>

          </div> 
      </div>
      <div class="col-xl-4 list-wrapper">
         <div class="bg-white p-4 rounded-3 shadow-sm border">
            <h5 class="mb-4">Categories</h5>
             <ul class="categories">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('categories', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>
          </div>
          <div class="recent-post p-4 bg-white rounded-4 border shadow-sm mt-4">
             <h5 class="mb-4">Recent Posts</h5>
             <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="d-flex">
                <?php if($blog->image && file_exists(public_path('images/blog/' . $blog->image))): ?>
                <img class="card-img-top rounded-3" width="60px" src="<?php echo e(asset('images/blog/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>" >
                <?php else: ?>
                <img src="assets/images/Listing-image-6.png" class="card-img-top rounded-3" width="60px" alt="<?php echo e($blog->title); ?>" >
                <?php endif; ?>
                <a class="fs-6 text-decoration-none title ps-3 text-dark" href="<?php echo e(url('blog/' . $blog->slug)); ?>"><?php echo e($blog->title); ?></a>
             </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
    </div>
    </div>
  </section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/frontend/blog/details.blade.php ENDPATH**/ ?>