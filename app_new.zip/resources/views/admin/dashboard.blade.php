@extends('admin.partials.layout')
@section('content')
 Welcome to dashboard
@endsection