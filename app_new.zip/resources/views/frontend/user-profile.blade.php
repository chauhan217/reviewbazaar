@extends('frontend.inc.layout')
@section('title', 'Uaer Profile')
@section('content')
@include('frontend.inc.profilesection')   

@endsection
